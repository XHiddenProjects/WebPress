<?php
$plugin='maintenance';
$lang[$plugin.'_name'] = 'Wartung';
$lang[$plugin.'_desc'] = 'Setzen Sie Ihre Website in den Wartungsmodus, Sie können auf den Admin-Bereich zugreifen.';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
$lang[$plugin.'_msg'] = 'Nachricht eingeben';
$lang[$plugin.'_submit'] = 'Senden';
$lang[$plugin.'mme'] = 'Wartungsmodus aktiviert';
$lang[$plugin.'messageAlert'] = 'Warnung, Ihre Sitzung als Administrator aktiv zu halten! Andernfalls löschen Sie die Datei manuell: <pre>data/plugins/maintenance/plugin.dat.json</pre>';
?>