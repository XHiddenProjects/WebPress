<?php
$plugin='maintenance';
$lang[$plugin.'_name'] = 'Manutenzione';
$lang[$plugin.'_desc'] = 'Imposta il tuo sito in modalità manutenzione, potrai accedere all`area di amministrazione.';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
$lang[$plugin.'_msg'] = 'Inserisci messaggio';
$lang[$plugin.'_submit'] = 'Invia';
$lang[$plugin.'mme'] = 'Modalità di manutenzione abilitata';
$lang[$plugin.'messageAlert'] = 'Avviso di mantenere attiva la sessione amministratore! Altrimenti cancella manualmente il file: <pre>data/plugins/maintenance/plugin.dat.json</pre>';
?>