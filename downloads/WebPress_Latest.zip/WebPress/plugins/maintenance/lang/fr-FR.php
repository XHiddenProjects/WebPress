<?php
$plugin='maintenance';
$lang[$plugin.'_name'] = 'Maintenance';
$lang[$plugin.'_desc'] = 'Mettez votre site en mode maintenance, vous pouvez accéder à la zone d\'administration.';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
$lang[$plugin.'_msg'] = 'Entrer le message';
$lang[$plugin.'_submit'] = 'Soumettre';
$lang[$plugin.'mme'] = 'Mode maintenance activé';
$lang[$plugin.'messageAlert'] = 'Attention pour garder votre session active administrateur ! Sinon supprimez manuellement le fichier : <pre>data/plugins/maintenance/plugin.dat.json</pre>';
?>