<?php
$plugin='Core';
$lang[$plugin.'_name'] = 'Core';
$lang[$plugin.'_desc'] = 'Easy way to run WebPress, activates and creates editors and etc.';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_updated'] = '04-03-2023';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
$lang['checkPolicy']='Check out the WebPress policy on the <a href="/'.MAINDIR.'/dashboard.php/docs#policy">documentation</a>';
?>