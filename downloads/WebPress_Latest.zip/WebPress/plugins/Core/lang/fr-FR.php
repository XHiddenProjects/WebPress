<?php
$plugin='Core';
$lang[$plugin.'_name'] = 'Cœur';
$lang[$plugin.'_desc'] = 'Un moyen facile d`exécuter WebPress, d`activer et de créer des éditeurs, etc.';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_updated'] = '03-27-2023';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
$lang['checkPolicy']='Consultez la politique WebPress sur la <a href="/'.MAINDIR.'/dashboard.php/docs#policy">documentation</a>';
?>