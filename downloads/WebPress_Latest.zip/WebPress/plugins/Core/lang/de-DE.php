<?php
$plugin='Core';
$lang[$plugin.'_name'] = 'Kern';
$lang[$plugin.'_desc'] = 'Einfache Möglichkeit, WebPress auszuführen, Editoren zu aktivieren und zu erstellen usw.';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_updated'] = '04-03-2023';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
$lang['checkPolicy']='Sehen Sie sich die WebPress-Richtlinie in der <a href="/'.MAINDIR.'/dashboard.php/docs#policy">Dokumentation</a> an';
?>