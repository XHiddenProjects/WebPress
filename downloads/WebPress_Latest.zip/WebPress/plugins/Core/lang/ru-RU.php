<?php
$plugin='Core';
$lang[$plugin.'_name'] = 'Ядро';
$lang[$plugin.'_desc'] = 'Простой способ запуска WebPress, активации и создания редакторов и т. д.';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_updated'] = '06-01-2023';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
$lang['checkPolicy']='Ознакомьтесь с политикой WebPress в <a href="/'.MAINDIR.'/dashboard.php/docs#policy">документации</a>';
?>