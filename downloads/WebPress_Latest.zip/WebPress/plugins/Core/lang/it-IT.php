<?php
$plugin='Core';
$lang[$plugin.'_name'] = 'Nucleo';
$lang[$plugin.'_desc'] = 'Modo semplice per eseguire WebPress, attivare e creare editor e così via.';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_updated'] = '05-20-2023';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
$lang['checkPolicy']='Consulta la politica di WebPress nella <a href="/'.MAINDIR.'/dashboard.php/docs#policy">documentazione</a>';
?>