<?php
$plugin='Core';
$lang[$plugin.'_name'] = '核';
$lang[$plugin.'_desc'] = '運行 WebPress、激活和創建編輯器等的簡單方法。';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_updated'] = '05-20-2023';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
$lang['checkPolicy']='查看 <a href="/'.MAINDIR.'/dashboard.php/docs#policy">文檔</a> 上的 WebPress 政策';
?>