<?php
$plugin='online';
$lang[$plugin.'_name'] = 'онлайн';
$lang[$plugin.'_desc'] = 'Показывает, кто находится в сети по конфигурации, а также отображает и кружит над изображением учетной записи на форуме и в нижнем колонтитуле.';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_updated'] = '06-01-2023';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
$lang[$plugin.'_color']='Выберите цвет';
$lang[$plugin.'_display']='Выберите дисплей';
$lang['blue']='синий';
$lang['gray']='серый';
$lang['green']='зеленый';
$lang['yellow']='желтый';
$lang['red']='красный';
$lang['black']='черный';
$lang['white']='белый';
$lang['icon']='значок';
$lang['text']='текст';
$lang[$plugin.'_submit']='Сохранить';
$lang['staff_online']='Сотрудники онлайн';
$lang['outline']='Онлайн';
?>