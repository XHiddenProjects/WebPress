<?php
$plugin='online';
$lang[$plugin.'_name'] = '在線的';
$lang[$plugin.'_desc'] = '通過配置顯示誰在線，並在論壇上的帳戶圖像頂部和頁腳顯示和圈出。';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_updated'] = '06-01-2023';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
$lang[$plugin.'_color']='選擇顏色';
$lang[$plugin.'_display']='選擇顯示';
$lang['blue']='藍色的';
$lang['gray']='灰色的';
$lang['green']='綠色';
$lang['yellow']='黃色';
$lang['red']='紅色的';
$lang['black']='黑色的';
$lang['white']='白色的';
$lang['icon']='圖標';
$lang['text']='文本';
$lang[$plugin.'_submit']='救';
$lang['staff_online']='員工在線';
$lang['online']='在線的 ';
?>