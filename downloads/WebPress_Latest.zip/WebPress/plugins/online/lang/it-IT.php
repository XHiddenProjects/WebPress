<?php
$plugin='online';
$lang[$plugin.'_name'] = 'in linea';
$lang[$plugin.'_desc'] = 'Mostra chi è online in base alla configurazione e mostra un cerchio sopra l`immagine dell`account sul forum e nel piè di pagina.';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_updated'] = '12-04-2022';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
$lang['online_color']='Seleziona Colore';
$lang['online_display']='Seleziona Visualizza';
$lang['blue']='blu';
$lang['gray']='grigio';
$lang['green']='verde';
$lang['yellow']='giallo';
$lang['red']='rosso';
$lang['black']='nero';
$lang['white']='bianca';
$lang['icon']='icona';
$lang['text']='testo';
$lang['online_submit']='Salva';
$lang['staff_online']='Personale in linea';
$lang['online']='in linea ';
?>