<?php
$plugin='online';
$lang[$plugin.'_name'] = 'en ligne';
$lang[$plugin.'_desc'] = 'Montre qui est en ligne par configuration et affiche et cercle en haut de l`image du compte sur le forum, et dans le pied de page.';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_updated'] = '12-04-2022';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
$lang[$plugin.'_color']='Choisissez la couleur';
$lang[$plugin.'_display']='Sélectionnez Affichage';
$lang['blue']='bleu';
$lang['gray']='gris';
$lang['green']='vert';
$lang['yellow']='jaune';
$lang['red']='rouge';
$lang['black']='noir';
$lang['white']='blanc';
$lang['icon']='icône';
$lang['text']='texte';
$lang[$plugin.'_submit']='sauvegarder';
$lang['staff_online']='Personnel en ligne';
$lang['online']='En ligne ';
?>