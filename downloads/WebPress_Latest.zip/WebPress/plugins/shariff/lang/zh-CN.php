<?php
$plugin='shariff';
$lang[$plugin.'_name'] = '謝里夫';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_updated'] = '03-30-2023';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
$lang[$plugin.'_desc']     = 'Shariff 使網站用戶能夠在不損害隱私的情況下分享他們喜歡的內容。';
$lang[$plugin.'_submit'] = '提交';
$lang['backend']   			= '後端'; 
$lang['data-theme']   		= '配色方案'; 
$lang['standard']			= '標準';
$lang['grey']  				= '灰色的';
$lang['white']				= '白色的';
$lang['data-backend']   	= '顯示分享數';
$lang[$plugin.'domaine']	= '域名（例如：www.domain.com）';
$lang['data-orientation']   = '按鈕方向';
$lang['vertical']   		= '垂直的';
$lang['horizontal']   		= '水平的';
$lang['data-services']   	= '要顯示的按鈕';  
$lang['data-services_desc'] = '可用的服務名稱： <code>&quot;twitter&quot;, &quot;facebook&quot;, &quot;linkedin&quot;, &quot;pinterest&quot;, &quot;xing&quot;, &quot;whatsapp&quot;, &quot;mail&quot;, &quot;info&quot;, &quot;addthis&quot;, &quot;tumblr&quot;, &quot;flattr&quot;, &quot;diaspora&quot;, &quot;reddit&quot;, &quot;stumbleupon&quot;, &quot;threema&quot;, &quot;weibo&quot;, &quot;tencent-weibo&quot;, &quot;qzone&quot;, &quot;print&quot;, &quot;telegram&quot;, &quot;vk&quot;, &quot;flipboard&quot;, &quot;pocket&quot;</code>';
?>