<?php
$plugin='calendar';
$lang[$plugin.'_name'] = 'Calendario';
$lang[$plugin.'_desc'] = 'Calendar è una build semplice che ti consente di organizzare il tuo programma e creare eventi, e può anche
avvisarti quando lo permetti';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_updated'] = '12-28-2022';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
$lang[$plugin.'_admin']='amministratore';
$lang[$plugin.'_any']='chiunque';
$lang[$plugin.'_submit']='Salva';
$lang[$plugin.'_listItem']='Calendario <i class="fa-solid fa-calendar-days"></i>';
$lang[$plugin.'_addEvent']='Aggiungi evento';
$lang[$plugin.'_addEventTitle'] = 'Crea un evento!';
$lang[$plugin.'_startDate'] = 'Data di inizio:';
$lang[$plugin.'_startTime'] = 'Ora di inizio:';
$lang[$plugin.'_endDate'] = 'Data di fine:';
$lang[$plugin.'_endTime'] = 'Ora di fine:';
$lang[$plugin.'eventName'] = 'Nome Evento:';
$lang[$plugin.'_labelColor'] = 'Colore etichetta:';
$lang[$plugin.'_removeEvent']='Rimuovi Evento';
$lang[$plugin.'_removeEventTitle']='Rimuovi un Evento!';
$lang[$plugin.'_removeEventtxt']='Conferma il nome dell`evento, l`operazione non può essere annullata.';
$lang[$plugin.'_labelIcon']='Icona Evento';
?>