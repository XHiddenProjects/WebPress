<?php
$plugin='calendar';
$lang[$plugin.'_name'] = '日曆';
$lang[$plugin.'_desc'] = '日曆是一個簡單的構建，可讓您組織日程和創建事件，還可以
當您允許時通知您';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_updated'] = '12-28-2022';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
$lang[$plugin.'_admin']='行政人員';
$lang[$plugin.'_any']='任何人';
$lang[$plugin.'_submit']='救';
$lang[$plugin.'_listItem']='日曆 <i class="fa-solid fa-calendar-days"></i>';
$lang[$plugin.'_addEvent']='添加事件';
$lang[$plugin.'_addEventTitle'] = '創建活動!';
$lang[$plugin.'_startDate'] = '開始日期:';
$lang[$plugin.'_startTime'] = '開始時間:';
$lang[$plugin.'_endDate'] = '結束日期:';
$lang[$plugin.'_endTime'] = '時間結束:';
$lang[$plugin.'eventName'] = '活動名稱:';
$lang[$plugin.'_labelColor'] = '標籤顏色:';
$lang[$plugin.'_removeEvent']='刪除事件';
$lang[$plugin.'_removeEventTitle']='刪除事件！';
$lang[$plugin.'_removeEventtxt']='確認您的活動名稱，此操作無法撤消。';
$lang[$plugin.'_labelIcon']='事件圖標';
?>