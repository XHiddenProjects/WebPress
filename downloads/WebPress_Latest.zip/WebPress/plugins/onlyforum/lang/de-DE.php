<?php
$plugin='onlyforum';
$lang[$plugin.'_name'] = 'Nur Forum';
$lang[$plugin.'_desc'] = 'Sperrt alle "Themen hinzufügen" für ein bestimmtes Forum. Nur Administratoren können Themen hinzufügen.';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_updated'] = '12-04-2022';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
$lang[$plugin.'_submit']='Submit';
$lang[$plugin.'_list']='Enter Forums';
?>