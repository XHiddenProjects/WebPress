<?php
$plugin='onlyforum';
$lang[$plugin.'_name'] = '唯一論壇';
$lang[$plugin.'_desc'] = '鎖定特定論壇的任何“添加主題”，只有管理員可以添加主題。';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_updated'] = '12-04-2022';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
$lang[$plugin.'_submit']='提交';
$lang[$plugin.'_list']='進入論壇';
?>