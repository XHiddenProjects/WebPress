<?php
$plugin='signature';
$lang[$plugin.'_name'] = 'Signature';
$lang[$plugin.'_desc'] = 'Adding a digital signature for specific user.';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_updated'] = '06-01-2023';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
$lang[$plugin.'_submit'] = 'Submit';
$lang[$plugin.'_users'] = 'Username';
$lang[$plugin.'_msg'] = 'Enter Signature';
$lang[$plugin.'_des'] = 'HTML is allowed, leave blank to remove signature';
?>