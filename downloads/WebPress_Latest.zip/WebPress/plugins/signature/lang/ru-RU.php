<?php
$plugin='signature';
$lang[$plugin.'_name'] = 'Подпись';
$lang[$plugin.'_desc'] = 'Добавление цифровой подписи для конкретного пользователя.';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_updated'] = '06-01-2023';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
$lang[$plugin.'_submit'] = 'Отправить';
$lang[$plugin.'_users'] = 'Имя пользователя';
$lang[$plugin.'_msg'] = 'Введите подпись';
$lang[$plugin.'_des'] = 'HTML разрешен, оставьте поле пустым, чтобы удалить подпись';
?>