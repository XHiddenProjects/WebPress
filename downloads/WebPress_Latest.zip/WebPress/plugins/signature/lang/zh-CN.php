<?php
$plugin='signature';
$lang[$plugin.'_name'] = '簽名';
$lang[$plugin.'_desc'] = '為特定用戶添加數字簽名。';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_updated'] = '01-29-2023';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
$lang[$plugin.'_submit'] = '提交';
$lang[$plugin.'_users'] = '用戶名';
$lang[$plugin.'_msg'] = '輸入簽名';
$lang[$plugin.'_des'] = '允許 HTML，留空以刪除簽名';
?>