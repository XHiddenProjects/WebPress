<?php
$plugin='signature';
$lang[$plugin.'_name'] = 'Signature';
$lang[$plugin.'_desc'] = 'Ajout d`une signature numérique pour un utilisateur spécifique.';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_updated'] = '01-29-2023';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
$lang[$plugin.'_submit'] = 'Soumettre';
$lang[$plugin.'_users'] = 'Nom d`utilisateur';
$lang[$plugin.'_msg'] = 'Entrer la signature';
$lang[$plugin.'_des'] = 'HTML est autorisé, laissez vide pour supprimer la signature';
?>