<?php
$plugin='signature';
$lang[$plugin.'_name'] = 'Firma';
$lang[$plugin.'_desc'] = 'Aggiunta di una firma digitale per un utente specifico.';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_updated'] = '06-01-2023';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
$lang[$plugin.'_submit'] = 'Invia';
$lang[$plugin.'_users'] = 'Nome utente';
$lang[$plugin.'_msg'] = 'Inserisci firma';
$lang[$plugin.'_des'] = 'HTML è consentito, lasciare vuoto per rimuovere la firma';
?>