<?php
$plugin='dataguard';
$lang[$plugin.'_name'] = 'Protezione dei dati';
$lang[$plugin.'_desc'] = 'Data Guard impedisce copia, incolla, taglio, menu contestuale e stampa per qualsiasi informazione che non lo fa
necessità di uso pubblico.';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
$lang[$plugin.'_updated'] = '12-29-2022';
$lang[$plugin.'_copy'] = 'Copia';
$lang[$plugin.'_cut'] = 'Tagliare';
$lang[$plugin.'_print'] = 'Stampa';
$lang[$plugin.'_menu'] = 'Menù contestuale';
$lang[$plugin.'_paste'] = 'Impasto';
$lang[$plugin.'_submit'] = 'Salva';
?>