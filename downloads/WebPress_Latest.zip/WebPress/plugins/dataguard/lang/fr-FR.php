<?php
$plugin='dataguard';
$lang[$plugin.'_name'] = 'Garde de données';
$lang[$plugin.'_desc'] = 'Data Guard empêche de copier, coller, couper, menu contextuel et imprimer pour toute information qui ne
besoin pour le public d`utiliser.';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
$lang[$plugin.'_updated'] = '12-29-2022';
$lang[$plugin.'_copy'] = 'Copie';
$lang[$plugin.'_cut'] = 'Couper';
$lang[$plugin.'_print'] = 'Imprimer';
$lang[$plugin.'_menu'] = 'Menu contextuel';
$lang[$plugin.'_paste'] = 'Pâte';
$lang[$plugin.'_submit'] = 'Sauver';
?>