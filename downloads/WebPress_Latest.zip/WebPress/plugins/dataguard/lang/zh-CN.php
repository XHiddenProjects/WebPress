<?php
$plugin='dataguard';
$lang[$plugin.'_name'] = '數據衛士';
$lang[$plugin.'_desc'] = 'Data Guard 可防止複制、粘貼、剪切、上下文菜單和打印任何不符合要求的信息
需要大眾使用。';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
$lang[$plugin.'_updated'] = '12-29-2022';
$lang[$plugin.'_copy'] = '複製';
$lang[$plugin.'_cut'] = '切';
$lang[$plugin.'_print'] = '打印';
$lang[$plugin.'_menu'] = '上下文菜單';
$lang[$plugin.'_paste'] = '粘貼';
$lang[$plugin.'_submit'] = '救';
?>