<?php
$plugin='nofollow';
$lang[$plugin.'_name'] = 'nicht folgen';
$lang[$plugin.'_desc'] = 'setzt ein "nofollow" auf ein Linkattribut';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_updated'] = '12-04-2022';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
?>