<?php
$plugin='nofollow';
$lang[$plugin.'_name'] = 'nofollow';
$lang[$plugin.'_desc'] = 'помещает "nofollow" в атрибут ссылки';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_updated'] = '06-01-2023';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
?>