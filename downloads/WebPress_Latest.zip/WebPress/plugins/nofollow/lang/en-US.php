<?php
$plugin='nofollow';
$lang[$plugin.'_name'] = 'nofollow';
$lang[$plugin.'_desc'] = 'puts a "nofollow" on a link attribute';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_updated'] = '06-01-2023';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
?>