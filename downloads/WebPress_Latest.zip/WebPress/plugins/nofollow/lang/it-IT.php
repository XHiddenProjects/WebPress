<?php
$plugin='nofollow';
$lang[$plugin.'_name'] = 'non seguire';
$lang[$plugin.'_desc'] = 'inserisce un "nofollow" su un attributo di collegamento';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_updated'] = '06-01-2023';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
?>