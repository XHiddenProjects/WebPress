<?php
$plugin='nofollow';
$lang[$plugin.'_name'] = 'non seguire';
$lang[$plugin.'_desc'] = 'inserisce un "nofollow" su un attributo di collegamento';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_updated'] = '12-04-2022';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
?>