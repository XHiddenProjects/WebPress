<?php
$plugin='nofollow';
$lang[$plugin.'_name'] = 'pas de suivi';
$lang[$plugin.'_desc'] = 'met un "nofollow" sur un attribut de lien';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_updated'] = '12-04-2022';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
?>