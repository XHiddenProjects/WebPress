<?php
$plugin='nofollow';
$lang[$plugin.'_name'] = '禁止關注';
$lang[$plugin.'_desc'] = '在鏈接屬性上放置“nofollow”';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_updated'] = '06-01-2023';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
?>