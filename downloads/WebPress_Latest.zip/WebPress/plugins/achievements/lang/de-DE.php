<?php
$plugin='achievements';
$lang[$plugin.'_name'] = 'Erfolge';
$lang[$plugin.'_desc'] = 'Verdienen Sie Erfolge basierend auf Ihren Aktionen, die auch der Öffentlichkeit als Trophäe gezeigt werden.';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_updated'] = '01-09-2023';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
$lang[$plugin.'_listItem'] = 'Erfolge <i class="fa-solid fa-trophy"></i>';
$lang[$plugin.'_welcome'] = ' Erfolge';
$lang['nouser'] = 'Benutzer existiert nicht';
?>