<?php
$plugin='achievements';
$lang[$plugin.'_name'] = 'Réalisations';
$lang[$plugin.'_desc'] = 'Gagnez des réalisations en fonction de vos actions que vous faites, cela sera également montré au public, comme un trophée.';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_updated'] = '01-09-2023';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
$lang[$plugin.'_listItem'] = 'Réalisations <i class="fa-solid fa-trophy"></i>';
$lang[$plugin.'_welcome'] = ' Réalisations';
$lang['nouser'] = 'L`utilisateur n`existe pas';
?>