<?php
$plugin='achievements';
$lang[$plugin.'_name'] = 'Achievements';
$lang[$plugin.'_desc'] = 'Earn achievements based on your actions you do, this will also be shown to public, as a trophy.';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_updated'] = '01-09-2023';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
$lang[$plugin.'_listItem'] = 'Achievements <i class="fa-solid fa-trophy"></i>';
$lang[$plugin.'_welcome'] = ' Achievements';
$lang['nouser'] = 'User does not exist';
?>