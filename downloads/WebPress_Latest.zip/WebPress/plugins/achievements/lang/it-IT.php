<?php
$plugin='achievements';
$lang[$plugin.'_name'] = 'Risultati';
$lang[$plugin.'_desc'] = 'Guadagna risultati in base alle tue azioni che fai, anche questo verrà mostrato al pubblico, come trofeo.';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_updated'] = '01-09-2023';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
$lang[$plugin.'_listItem'] = 'Risultati <i class="fa-solid fa-trophy"></i>';
$lang[$plugin.'_welcome'] = ' Risultati';
$lang['nouser'] = 'l`utente non esiste';
?>