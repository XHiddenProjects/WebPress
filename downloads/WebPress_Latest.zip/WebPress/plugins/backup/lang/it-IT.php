<?php
$plugin='backup';
$lang[$plugin.'_name'] = 'Backup';
$lang[$plugin.'_desc'] = 'Esegui il backup dei dati utilizzando questo plug-in, creerà una nuova cartella nella cartella ROOT';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
$lang[$plugin.'_updated'] = '06-01-2023';
$lang['backup_listItem']='Backup <i class="fa-solid fa-server"></i>';
$lang['backup_mkdir']='Impossibile creare il backup';
$lang['backup_nodir']='Questa directory non esiste';
$lang['backup_version']='Versione';
$lang['backup_delete']='Elimina';
$lang['backup_restore']='Ristabilire';
$lang['backup_download']='Scarica';
$lang['backup_createBackup']='Creare il backup';
?>