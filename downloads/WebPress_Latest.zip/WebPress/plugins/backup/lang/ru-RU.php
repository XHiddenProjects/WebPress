<?php
$plugin='backup';
$lang[$plugin.'_name'] = 'Резервное копирование';
$lang[$plugin.'_desc'] = 'Создайте резервную копию ваших данных с помощью этого плагина, он создаст новую папку в корневой папке';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_updated'] = '06-01-2023';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
$lang['backup_listItem']='Резервное копирование <i class="fa-solid fa-server"></i>';
$lang['backup_mkdir']='не удалось создать резервную копию';
$lang['backup_nodir']='Этот каталог не существует';
$lang['backup_version']='Версия';
$lang['backup_delete']='Удалить';
$lang['backup_restore']='Восстановить';
$lang['backup_download']='Скачать';
$lang['backup_createBackup']='Создать резервную копию';
?>