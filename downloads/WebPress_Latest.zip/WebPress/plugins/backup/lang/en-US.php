<?php
$plugin='backup';
$lang[$plugin.'_name'] = 'Backup';
$lang[$plugin.'_desc'] = 'Backup your data by using this plugin, it will create a new folder in the ROOT folder';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_updated'] = '06-01-2023';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
$lang['backup_listItem']='Backup <i class="fa-solid fa-server"></i>';
$lang['backup_mkdir']='failed to create backup';
$lang['backup_nodir']='This directory does not exists';
$lang['backup_version']='Version';
$lang['backup_delete']='Delete';
$lang['backup_restore']='Restore';
$lang['backup_download']='Download';
$lang['backup_createBackup']='Create Backup';
?>