<?php
$plugin='backup';
$lang[$plugin.'_name'] = 'Sauvegarde';
$lang[$plugin.'_desc'] = 'Sauvegardez vos données en utilisant ce plugin, il créera un nouveau dossier dans le dossier ROOT';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_updated'] = '12-04-2022';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
$lang['backup_listItem']='Sauvegarde <i class="fa-solid fa-server"></i>';
$lang['backup_mkdir']='échec de la création de la sauvegarde';
$lang['backup_nodir']='Ce répertoire n`existe pas';
$lang['backup_version']='Version';
$lang['backup_delete']='Effacer';
$lang['backup_restore']='Restaurer';
$lang['backup_download']='Télécharger';
$lang['backup_createBackup']='Créer une sauvegarde';
?>