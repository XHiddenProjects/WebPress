<?php
$plugin='scrolltop';
$lang[$plugin.'_name'] = 'Scorrere verso l`alto';
$lang[$plugin.'_desc'] = 'Scorri verso l`alto con i pulsanti personalizzati';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_updated'] = '01-07-2023';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
$lang[$plugin.'_submit'] = 'Invia';
$lang['up-arrow.png']='freccia-su';
$lang['up-arrow10.png']='freccia-su10';
$lang['up-arrow2.png']='freccia-su2';
$lang['up-arrow3.png']='freccia-su3';
$lang['up-arrow4.png']='freccia-su4';
$lang['up-arrow5.png']='freccia-su5';
$lang['up-arrow6.png']='freccia-su6';
$lang['up-arrow7.png']='freccia-su7';
$lang['up-arrow8.png']='freccia-su8';
$lang['up-arrow9.png']='freccia-su9';
$lang['design']='Progetto';
$lang['top']='sopra';
?>