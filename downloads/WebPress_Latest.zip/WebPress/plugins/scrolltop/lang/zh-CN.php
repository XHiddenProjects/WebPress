<?php
$plugin='scrolltop';
$lang[$plugin.'_name'] = '滾動到頂部';
$lang[$plugin.'_desc'] = '使用自定義按鈕滾動到頂部';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_updated'] = '01-07-2023';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
$lang[$plugin.'_submit'] = '提交';
$lang['up-arrow.png']='向上箭頭';
$lang['up-arrow10.png']='向上箭頭10';
$lang['up-arrow2.png']='上箭頭2';
$lang['up-arrow3.png']='向上箭頭3';
$lang['up-arrow4.png']='向上箭頭4';
$lang['up-arrow5.png']='向上箭頭5';
$lang['up-arrow6.png']='向上箭頭6';
$lang['up-arrow7.png']='向上箭頭7';
$lang['up-arrow8.png']='向上箭頭8';
$lang['up-arrow9.png']='向上箭頭9';
$lang['design']='設計';
$lang['top']='最佳';
?>