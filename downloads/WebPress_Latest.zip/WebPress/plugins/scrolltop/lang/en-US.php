<?php
$plugin='scrolltop';
$lang[$plugin.'_name'] = 'Scroll to Top';
$lang[$plugin.'_desc'] = 'Scroll to the top with custom buttons';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_updated'] = '01-07-2023';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
$lang[$plugin.'_submit'] = 'Submit';
$lang['up-arrow.png']='up-arrow';
$lang['up-arrow10.png']='up-arrow10';
$lang['up-arrow2.png']='up-arrow2';
$lang['up-arrow3.png']='up-arrow3';
$lang['up-arrow4.png']='up-arrow4';
$lang['up-arrow5.png']='up-arrow5';
$lang['up-arrow6.png']='up-arrow6';
$lang['up-arrow7.png']='up-arrow7';
$lang['up-arrow8.png']='up-arrow8';
$lang['up-arrow9.png']='up-arrow9';
$lang['design']='Design';
$lang['top']='Top';
?>