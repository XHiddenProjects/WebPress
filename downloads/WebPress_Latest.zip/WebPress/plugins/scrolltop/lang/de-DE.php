<?php
$plugin='scrolltop';
$lang[$plugin.'_name'] = 'Nach oben scrollen';
$lang[$plugin.'_desc'] = 'Scrollen Sie mit benutzerdefinierten Schaltflächen nach oben';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_updated'] = '01-07-2023';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
$lang[$plugin.'_submit'] = 'einreichen';
$lang['up-arrow.png']='Aufwärtspfeil';
$lang['up-arrow10.png']='Aufwärtspfeil10';
$lang['up-arrow2.png']='Aufwärtspfeil2';
$lang['up-arrow3.png']='Aufwärtspfeil3';
$lang['up-arrow4.png']='Aufwärtspfeil4';
$lang['up-arrow5.png']='Aufwärtspfeil5';
$lang['up-arrow6.png']='Aufwärtspfeil6';
$lang['up-arrow7.png']='Aufwärtspfeil7';
$lang['up-arrow8.png']='Aufwärtspfeil8';
$lang['up-arrow9.png']='Aufwärtspfeil9';
$lang['design']='Design';
$lang['top']='oben';
?>