<?php
$plugin='scrolltop';
$lang[$plugin.'_name'] = 'Faites défiler vers le haut';
$lang[$plugin.'_desc'] = 'Faites défiler vers le haut avec des boutons personnalisés';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_updated'] = '01-07-2023';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
$lang[$plugin.'_submit'] = 'Nous faire parvenir';
$lang['up-arrow.png']='flèche vers le haut';
$lang['up-arrow10.png']='flèche vers le haut10';
$lang['up-arrow2.png']='flèche vers le haut2';
$lang['up-arrow3.png']='flèche vers le haut3';
$lang['up-arrow4.png']='flèche vers le haut4';
$lang['up-arrow5.png']='flèche vers le haut5';
$lang['up-arrow6.png']='flèche vers le haut6';
$lang['up-arrow7.png']='flèche vers le haut7';
$lang['up-arrow8.png']='flèche vers le haut8';
$lang['up-arrow9.png']='flèche vers le haut9';
$lang['design']='Concevoir';
$lang['top']='Haut';
?>