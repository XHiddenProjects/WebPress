<?php
$plugin='hidder';
$lang[$plugin.'_name'] = '隱藏器';
$lang[$plugin.'_desc'] = '使用簡單的代碼能夠對其他用戶/特定組隱藏文本並切換開關下拉列表。';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_updated'] = '06-01-2023';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
$lang[$plugin.'_showmore'] = '顯示更多...';
$lang[$plugin.'isHide'] = '<i class="fa-solid fa-triangle-exclamation"></i> 這適用於所有登錄用戶！';
$lang[$plugin.'isHideMod'] = '<i class="fa-solid fa-triangle-exclamation"></i> 此消息是給版主的！';
$lang[$plugin.'isHideUser'] = '<i class="fa-solid fa-triangle-exclamation"></i> 此消息是針對特定用戶的！';
?>