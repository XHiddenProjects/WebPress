<?php
$plugin='hidder';
$lang[$plugin.'_name'] = 'Hidder';
$lang[$plugin.'_desc'] = 'Use simple codes to be able to hide text from other users/specific groups and to toggle switch dropdown.';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_updated'] = '04-01-2023';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
$lang[$plugin.'_showmore'] = 'Show more...';
$lang[$plugin.'isHide']  = '<i class="fa-solid fa-triangle-exclamation"></i> This is for any logged in users!';
$lang[$plugin.'isHideMod'] = '<i class="fa-solid fa-triangle-exclamation"></i> This message is for moderators!';
$lang[$plugin.'isHideUser'] = '<i class="fa-solid fa-triangle-exclamation"></i> This message is for specific user!';
?>