<?php
$plugin='reactions';
$lang[$plugin.'_name'] = 'реакции';
$lang[$plugin.'_desc'] = 'Реагирует на любые отображаемые ответы';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_updated'] = '06-01-2023';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
$lang[$plugin.'_submit'] = 'Отправить';
$lang[$plugin.'_reactionList']='Реакции';
$lang[$plugin.'_reactionIcon']='Добавить значок';
$lang[$plugin.'_reactionName']='Имя эмодзи';
$lang[$plugin.'_nouser']='Вы должны войти в систему, чтобы проголосовать';
$lang[$plugin.'_additonal']='дополнительно';
?>