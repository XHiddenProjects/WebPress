<?php
$plugin='reactions';
$lang[$plugin.'_name'] = 'Reazioni';
$lang[$plugin.'_desc'] = 'Reagisce a tutte le risposte visualizzate';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_updated'] = '03-30-2023';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
$lang[$plugin.'_submit'] = 'Invia';
$lang[$plugin.'_reactionList']='Reazioni';
$lang[$plugin.'_reactionIcon']='Aggiungi icona';
$lang[$plugin.'_reactionName']='Nome emoticon';
$lang[$plugin.'_nouser']='Devi loggarti per votare';
$lang[$plugin.'_additonal']='aggiuntivo';
?>