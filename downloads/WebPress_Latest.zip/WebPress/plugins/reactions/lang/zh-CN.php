<?php
$plugin='reactions';
$lang[$plugin.'_name'] = '反應';
$lang[$plugin.'_desc'] = '對顯示的任何回复做出反應';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_updated'] = '03-30-2023';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
$lang[$plugin.'_submit'] = '提交';
$lang[$plugin.'_reactionList']='反應';
$lang[$plugin.'_reactionIcon']='添加圖標';
$lang[$plugin.'_reactionName']='表情名稱';
$lang[$plugin.'_nouser']='您必須登錄才能投票';
$lang[$plugin.'_additonal']='額外的';
?>