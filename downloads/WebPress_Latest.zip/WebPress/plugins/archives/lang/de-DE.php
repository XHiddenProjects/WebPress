<?php
$plugin='archives';
$lang[$plugin.'_name'] = 'Archiv';
$lang[$plugin.'_desc'] = 'Generieren Sie eine Archivseite nach Jahren zu allen Themen, sortiert nach Monaten.';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_updated'] = '01-12-2023';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
$lang[$plugin.'_Listname'] = 'Archiv';
$lang[$plugin.'_no_archive'] = 'Keine Archive';
$lang[$plugin.'_back'] = 'Der Rücken';
?>