<?php
$plugin='archives';
$lang[$plugin.'_name'] = '檔案';
$lang[$plugin.'_desc'] = '按年生成所有主題的檔案頁面，按月排序。';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_updated'] = '01-12-2023';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
$lang[$plugin.'_Listname'] = '檔案';
$lang[$plugin.'_no_archive'] = '沒有檔案';
$lang[$plugin.'_back'] = '後退';
?>