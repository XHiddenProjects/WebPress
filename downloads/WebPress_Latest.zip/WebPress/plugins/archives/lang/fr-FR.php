<?php
$plugin='archives';
$lang[$plugin.'_name'] = 'Les archives';
$lang[$plugin.'_desc'] = 'Générer une page d`archives par années sur tous les sujets, trier par mois.';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_updated'] = '01-12-2023';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
$lang[$plugin.'_Listname'] = 'Les archives';
$lang[$plugin.'_no_archive'] = 'Aucune archive';
$lang[$plugin.'_back'] = 'Arrière';
?>