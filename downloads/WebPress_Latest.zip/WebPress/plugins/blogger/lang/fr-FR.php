<?php
$plugin='blogger';
$lang[$plugin.'_name'] = 'Blogueur';
$lang[$plugin.'_desc'] = 'Créez des blogs avec des éditeurs simples et simples, lors de la visualisation, il mettra automatiquement à jour les textes d`URL en URL valides';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_updated'] = '12-12-2022';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
$lang[$plugin.'_viewBlog'] = 'Blogues';
$lang[$plugin.'_submit'] = 'Nous faire parvenir';
$lang['button']='bouton';
$lang['link']='lien';
$lang['outline']='contour';
$lang[$plugin.'Color']='Couleur:';
$lang[$plugin.'Display']='Afficher:';
$lang[$plugin.'_pageDescription']='Entrez la description <span class="bg-secondary badge">(<span class="totalCount">0</span>/500 personnages)</span>';
$lang[$plugin.'_pageName']='Entrez le nom (utilisez le nom pour modifier)';
$lang[$plugin.'_pageLogo']='Télécharger la bannière';
$lang[$plugin.'_warn']='Une fois que vous soumettez, vous ne pouvez pas modifier après.';
$lang[$plugin.'Show']='Afficher les blogs/page';
$lang[$plugin.'_listItem']='Blogues <i class="fa-solid fa-blog"></i>';
?>