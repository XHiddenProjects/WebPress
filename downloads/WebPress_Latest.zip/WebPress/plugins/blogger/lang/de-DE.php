<?php
$plugin='blogger';
$lang[$plugin.'_name'] = 'Blogger';
$lang[$plugin.'_desc'] = 'Erstellen Sie Blogs mit einfachen Editoren. Beim Anzeigen werden URL-Texte automatisch auf gültige URLs aktualisiert';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_updated'] = '12-12-2022';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
$lang[$plugin.'_viewBlog'] = 'Blogs';
$lang[$plugin.'_submit'] = 'einreichen';
$lang['button']='Knopf';
$lang['link']='Verknüpfung';
$lang['outline']='Gliederung';
$lang[$plugin.'Color']='Farbe:';
$lang[$plugin.'Display']='Anzeige:';
$lang[$plugin.'_pageDescription']='Beschreibung eingeben <span class="bg-secondary badge">(<span class="totalCount">0</span>/500 Figuren)</span>';
$lang[$plugin.'_pageName']='Name eingeben (Name zum Bearbeiten verwenden)';
$lang[$plugin.'_pageLogo']='Banner hochladen';
$lang[$plugin.'_warn']='Sobald Sie es gesendet haben, können Sie es nicht mehr bearbeiten.';
$lang[$plugin.'Show']='Blogs/Seite anzeigen';
$lang[$plugin.'_listItem']='Blogs <i class="fa-solid fa-blog"></i>';
?>