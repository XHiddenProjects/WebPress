<?php
$plugin='blogger';
$lang[$plugin.'_name'] = 'Blogger';
$lang[$plugin.'_desc'] = 'Crea blog con semplici editor semplici, durante la visualizzazione aggiornerà automaticamente i testi degli URL in URL validi';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_updated'] = '12-12-2022';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
$lang[$plugin.'_viewBlog'] = 'Blogs';
$lang[$plugin.'_submit'] = 'Invia';
$lang['button']='pulsante';
$lang['link']='collegamento';
$lang['outline']='schema';
$lang[$plugin.'Color']='Colore:';
$lang[$plugin.'Display']='Schermo:';
$lang[$plugin.'_pageDescription']='Inserisci la descrizione <span class="bg-secondary badge">(<span class="totalCount">0</span>/500 personaggi)</span>';
$lang[$plugin.'_pageName']='Inserisci il nome (usa il nome per modificare)';
$lang[$plugin.'_pageLogo']='Carica banner';
$lang[$plugin.'_warn']='Una volta inviato non è possibile modificare dopo.';
$lang[$plugin.'Show']='Visualizza blog/pagina';
$lang[$plugin.'_listItem']='Blogs <i class="fa-solid fa-blog"></i>';
?>