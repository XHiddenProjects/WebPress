window.addEventListener('load', function(){
	console.info('%cSuccessfully loaded WebPress[Core]', 'background-color:green;color:lime;');	
});

