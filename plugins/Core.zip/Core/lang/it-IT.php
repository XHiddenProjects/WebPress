<?php
$plugin='Core';
$lang[$plugin.'_name'] = 'Nucleo';
$lang[$plugin.'_desc'] = 'Modo semplice per eseguire WebPress, attivare e creare editor e così via...';
$lang['checkPolicy']='Consulta la politica di WebPress nella <a href="/dashboard.php/docs#policy">documentazione</a>';
?>