<?php
$plugin='Core';
$lang[$plugin.'_name'] = 'Core';
$lang[$plugin.'_desc'] = 'Easy way to run WebPress, activates and creates editors and etc...';
$lang['checkPolicy']='Check out the WebPress policy on the <a href="/dashboard.php/docs#policy">documentation</a>';
?>