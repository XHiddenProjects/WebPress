<?php
$plugin='Core';
$lang[$plugin.'_name'] = 'Kern';
$lang[$plugin.'_desc'] = 'Einfache Möglichkeit, WebPress auszuführen, Editoren zu aktivieren und zu erstellen usw..';
$lang['checkPolicy']='Sehen Sie sich die WebPress-Richtlinie in der <a href="/dashboard.php/docs#policy">Dokumentation</a> an';
?>