<?php
$plugin='nofollow';
$lang[$plugin.'_name'] = 'nofollow';
$lang[$plugin.'_desc'] = 'puts a "nofollow" on a link attribute';
?>