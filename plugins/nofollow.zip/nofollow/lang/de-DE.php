<?php
$plugin='nofollow';
$lang[$plugin.'_name'] = 'nicht folgen';
$lang[$plugin.'_desc'] = 'setzt ein "nofollow" auf ein Linkattribut';
?>