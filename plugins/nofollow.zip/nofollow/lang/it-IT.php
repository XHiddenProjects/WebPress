<?php
$plugin='nofollow';
$lang[$plugin.'_name'] = 'non seguire';
$lang[$plugin.'_desc'] = 'inserisce un "nofollow" su un attributo di collegamento';
?>