<?php
$plugin='backup';
$lang[$plugin.'_name'] = 'Sicherung';
$lang[$plugin.'_desc'] = 'Backup your data by using this plugin, it will create a new folder in the ROOT folder';
$lang['backup_listItem']='<i class="fa-solid fa-server"></i> Sicherung';
$lang['backup_mkdir']='Sicherung konnte nicht erstellt werden';
$lang['backup_nodir']='Dieses Verzeichnis existiert nicht';
$lang['backup_version']='Ausführung';
$lang['backup_delete']='Löschen';
$lang['backup_restore']='Wiederherstellen';
$lang['backup_download']='Download';
$lang['backup_createBackup']='Ein Backup erstellen';
?>