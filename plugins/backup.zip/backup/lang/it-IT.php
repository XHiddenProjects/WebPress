<?php
$plugin='backup';
$lang[$plugin.'_name'] = 'Backup';
$lang[$plugin.'_desc'] = 'Esegui il backup dei dati utilizzando questo plug-in, creerà una nuova cartella nella cartella ROOT';
$lang['backup_listItem']='<i class="fa-solid fa-server"></i> Backup';
$lang['backup_mkdir']='Impossibile creare il backup';
$lang['backup_nodir']='Questa directory non esiste';
$lang['backup_version']='Versione';
$lang['backup_delete']='Elimina';
$lang['backup_restore']='Ristabilire';
$lang['backup_download']='Scarica';
$lang['backup_createBackup']='Creare il backup';
?>