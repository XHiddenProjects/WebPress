<?php
$plugin='online';
$lang[$plugin.'_name'] = 'online';
$lang[$plugin.'_desc'] = 'Shows who is online by configuration and displays and circle on top of the account image on the forum, and in the footer.';
$lang[$plugin.'_color']='Select Color';
$lang[$plugin.'_display']='Select Display';
$lang['blue']='blue';
$lang['gray']='gray';
$lang['green']='green';
$lang['yellow']='yellow';
$lang['red']='red';
$lang['black']='black';
$lang['white']='white';
$lang['icon']='icon';
$lang['text']='text';
$lang[$plugin.'_submit']='Save';
$lang['staff_online']='Staff Online';
$lang['online']='Online ';
?>