<?php
$plugin='onlyforum';
$lang[$plugin.'_name'] = 'nicht seguire';
$lang[$plugin.'_desc'] = 'Blocca qualsiasi "aggiungi argomenti" per un forum specifico, solo gli amministratori possono aggiungere argomenti.';
$lang[$plugin.'_submit']='Submit';
$lang[$plugin.'_list']='Enter Forums';
?>