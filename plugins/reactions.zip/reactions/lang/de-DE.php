<?php
$plugin='onlyforum';
$lang[$plugin.'_name'] = 'Nur Forum';
$lang[$plugin.'_desc'] = 'Sperrt alle "Themen hinzufügen" für ein bestimmtes Forum. Nur Administratoren können Themen hinzufügen.';
$lang[$plugin.'_submit']='Submit';
$lang[$plugin.'_list']='Enter Forums';
?>