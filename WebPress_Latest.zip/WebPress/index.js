function webpressinstall(string){
    return string === 'webpressinstall';
}

module.export = webpressinstall;