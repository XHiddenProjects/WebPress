<?php
$plugin='onlyforum';
$lang[$plugin.'_name'] = 'uniquementforum';
$lang[$plugin.'_desc'] = 'Verrouille tout "ajouter des sujets" pour un forum spécifique, Seuls les administrateurs peuvent ajouter des sujets.';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_updated'] = '12-04-2022';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
$lang[$plugin.'_submit']='Soumettre';
$lang[$plugin.'_list']='Entrez dans les forums';
?>