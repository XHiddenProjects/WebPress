<?php
$plugin='onlyforum';
$lang[$plugin.'_name'] = 'onlyforum';
$lang[$plugin.'_desc'] = 'Locks any "add topics" for a specific forum, Only admins can add topics.';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_updated'] = '12-04-2022';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
$lang[$plugin.'_submit']='Submit';
$lang[$plugin.'_list']='Enter Forums';
?>