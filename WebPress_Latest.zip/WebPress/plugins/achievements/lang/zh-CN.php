<?php
$plugin='achievements';
$lang[$plugin.'_name'] = '成就';
$lang[$plugin.'_desc'] = '根據您的行為獲得成就，這也將作為獎杯向公眾展示。';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_updated'] = '01-09-2023';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
$lang[$plugin.'_listItem'] = '成就 <i class="fa-solid fa-trophy"></i>';
$lang[$plugin.'_welcome'] = ' 成就';
$lang['nouser'] = '用戶不存在';
?>