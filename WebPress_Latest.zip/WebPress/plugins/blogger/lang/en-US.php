<?php
$plugin='blogger';
$lang[$plugin.'_name'] = 'Blogger';
$lang[$plugin.'_desc'] = 'Create Blogs with easy simple editors, When viewing it will automatically update URL texts to valid URLS';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_updated'] = '12-12-2022';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
$lang[$plugin.'_viewBlog'] = 'Blogs';
$lang[$plugin.'_submit'] = 'Submit';
$lang['button']='button';
$lang['link']='link';
$lang['outline']='outline';
$lang[$plugin.'Color']='Color:';
$lang[$plugin.'Display']='Display:';
$lang[$plugin.'_pageDescription']='Enter description <span class="bg-secondary badge">(<span class="totalCount">0</span>/500 characters)</span>';
$lang[$plugin.'_pageName']='Enter Name(use name to edit)';
$lang[$plugin.'_pageLogo']='Upload Banner';
$lang[$plugin.'_warn']='Once you submit you cannot edit after.';
$lang[$plugin.'Show']='Display Blogs/page';
$lang[$plugin.'_listItem']='Blogs <i class="fa-solid fa-blog"></i>';
?>