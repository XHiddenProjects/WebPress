<?php
$plugin='maintenance';
$lang[$plugin.'_name'] = '維護';
$lang[$plugin.'_desc'] = '將您的站點設置為維護模式，您可以訪問管理區域。';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
$lang[$plugin.'_updated'] = '01-14-2023';
$lang[$plugin.'_msg'] = '輸入消息';
$lang[$plugin.'_submit'] = '提交';
$lang[$plugin.'mme']     	 	 = '啟用維護模式';
$lang[$plugin.'messageAlert']    = '管理員警告讓您的會話保持活動狀態！ 否則手動刪除文件: <pre>data/plugins/maintenance/plugin.dat.json</pre>';
?>