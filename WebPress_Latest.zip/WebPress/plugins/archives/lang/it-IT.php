<?php
$plugin='archives';
$lang[$plugin.'_name'] = 'Archivi';
$lang[$plugin.'_desc'] = 'Genera una pagina di archivio per anni su tutti gli argomenti, ordina per mesi.';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_updated'] = '01-12-2023';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
$lang[$plugin.'_Listname'] = 'Archivi';
$lang[$plugin.'_no_archive'] = 'Nessun archivio';
$lang[$plugin.'_back'] = 'Indietro';
?>