<?php
$plugin='archives';
$lang[$plugin.'_name'] = 'Archives';
$lang[$plugin.'_desc'] = 'Generate a archives page by years on all topics, sort by months.';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_updated'] = '01-12-2023';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
$lang[$plugin.'_Listname'] = 'Archives';
$lang[$plugin.'_no_archive'] = 'No Archives';
$lang[$plugin.'_back'] = 'Back';
?>