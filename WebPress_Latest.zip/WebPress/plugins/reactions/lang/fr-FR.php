<?php
$plugin='reactions';
$lang[$plugin.'_name'] = 'réactions';
$lang[$plugin.'_desc'] = 'Réagit à toutes les réponses affichées';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_updated'] = '12-04-2022';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
$lang[$plugin.'_submit'] = 'Soumettre';
$lang[$plugin.'_reactionList']='Réactions';
$lang[$plugin.'_reactionIcon']='Ajouter une icône';
$lang[$plugin.'_reactionName']='Nom de l`émoji';
$lang[$plugin.'_nouser']='Vous devez vous connecter pour voter';
$lang[$plugin.'_additonal']='additionnel';
?>