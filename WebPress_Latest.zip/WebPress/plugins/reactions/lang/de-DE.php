<?php
$plugin='reactions';
$lang[$plugin.'_name'] = 'Reaktionen';
$lang[$plugin.'_desc'] = 'Reagiert auf alle angezeigten Antworten';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_updated'] = '12-04-2022';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
$lang[$plugin.'_submit'] = 'Einreichen';
$lang[$plugin.'_reactionList']='Reaktionen';
$lang[$plugin.'_reactionIcon']='Symbol hinzufügen';
$lang[$plugin.'_reactionName']='Emoji Name';
$lang[$plugin.'_nouser']='Sie müssen sich anmelden, um abzustimmen';
$lang[$plugin.'_additonal']='zusätzlich';
?>