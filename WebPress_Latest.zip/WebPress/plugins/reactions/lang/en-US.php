<?php
$plugin='reactions';
$lang[$plugin.'_name'] = 'reactions';
$lang[$plugin.'_desc'] = 'Reacts to any replies that are shown';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_updated'] = '12-04-2022';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
$lang[$plugin.'_submit'] = 'Submit';
$lang[$plugin.'_reactionList']='Reactions';
$lang[$plugin.'_reactionIcon']='Add Icon';
$lang[$plugin.'_reactionName']='Emoji Name';
$lang[$plugin.'_nouser']='You must login to vote';
$lang[$plugin.'_additonal']='additional';
?>