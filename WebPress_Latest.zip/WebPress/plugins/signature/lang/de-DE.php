<?php
$plugin='signature';
$lang[$plugin.'_name'] = 'Signatur';
$lang[$plugin.'_desc'] = 'Hinzufügen einer digitalen Signatur für einen bestimmten Benutzer.';
$lang[$plugin.'_author'] = 'SurveyBuilderTeams';
$lang[$plugin.'_updated'] = '01-29-2023';
$lang[$plugin.'_homepage'] = 'https://github.com/surveybuilderteams/webpress';
$lang[$plugin.'_submit'] = 'Senden';
$lang[$plugin.'_users'] = 'Benutzername';
$lang[$plugin.'_msg'] = 'Signatur eingeben';
$lang[$plugin.'_des'] = 'HTML ist erlaubt, leer lassen um Signatur zu entfernen';
?>